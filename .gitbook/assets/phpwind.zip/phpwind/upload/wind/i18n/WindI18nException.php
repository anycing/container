<?php
/**
 * @author Qiong Wu <papa0924@gmail.com> 2011-11-16
 * @copyright ©2003-2103 phpwind.com
 * @license http://www.windframework.com
 * @version $Id$
 * @package i18n
 */
class WindI18nException extends WindException {


}

?>