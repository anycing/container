<?php
//define('WEKIT_PATH', dirname(__FILE__) . DIRECTORY_SEPARATOR);
//define('WEKIT_VERSION', '0.2');

Wind::import('SRC:bootstrap.phpwindBoot');

/**
 * @author Jianmin Chen <sky_hold@163.com>
 * @version $Id: acloudBoot.php 21644 2012-12-12 05:12:46Z jieyin $
 * @package wekit
 */
class acloudBoot extends phpwindBoot {
	
}