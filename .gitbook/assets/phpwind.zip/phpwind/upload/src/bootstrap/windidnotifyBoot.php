<?php

Wind::import('SRC:bootstrap.phpwindBoot');

/**
 * @author Jianmin Chen <sky_hold@163.com>
 * @version $Id: windidnotifyBoot.php 24193 2013-01-22 14:43:42Z jieyin $
 * @package wekit
 */
class windidnotifyBoot extends phpwindBoot {
	
	/* (non-PHPdoc)
	 * @see phpwind::runApps()
	 */
	public function runApps($front = null) {
	}
	
	/* (non-PHPdoc)
	 * @see phpwind::_initUser()
	 */
	protected function _initUser() {
		
	}
}